package com.multipixeltec.dcservice.controller;

import com.multipixeltec.dcservice.model.BillPayment;
import com.multipixeltec.dcservice.service.BillPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/v1")
public class BillPaymentController {

    @Autowired
    private BillPaymentService billpaymentService;

    @PostMapping("/billpayment")
    public BillPayment save(@RequestBody BillPayment billpayment){
        return billpaymentService.save(billpayment);
    }

    @GetMapping("/billpayment/{id}")
    public Optional<BillPayment> getById(@PathVariable(value = "id") Long id){
        return billpaymentService.find(id);
    }

    @GetMapping("/billpayment")
    public List<BillPayment> getAll(){
        return billpaymentService.findAll();
    }

    @DeleteMapping("/billpayment/{id}")
    public void deleteById(@PathVariable(value = "id") Long id){
        billpaymentService.delete(id);
    }

    @DeleteMapping("/billpayment")
    public void deleteAll(){
        billpaymentService.deleteAll();
    }

    @GetMapping("/billpayment/count")
    public long count(){
        return billpaymentService.count();
    }
}