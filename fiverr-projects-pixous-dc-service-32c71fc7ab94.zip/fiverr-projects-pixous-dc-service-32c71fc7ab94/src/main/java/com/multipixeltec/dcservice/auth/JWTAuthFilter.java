package com.multipixeltec.dcservice.auth;

import com.multipixeltec.dcservice.util.AppUserDetails;
import com.multipixeltec.dcservice.util.JwtUtil;
import io.jsonwebtoken.ExpiredJwtException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.filter.OncePerRequestFilter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Copyright (C) 2023 PIXOUS INNOVATIONS - All Rights Reserved
 * You may use, distribute and modify this code under the terms of the XYZ license,
 * which unfortunately won't be written for another century.
 * Project   : dc-service
 * Date      : 2023-01-04
 * Developer : priyamal
 */
public class JWTAuthFilter extends OncePerRequestFilter {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private JwtUtil jwtTokenUtil;
    private UserDetailsService userDetailsService;

    public JWTAuthFilter(JwtUtil jwtTokenUtil, UserDetailsService userDetailsService) {
        this.jwtTokenUtil = jwtTokenUtil;
        this.userDetailsService = userDetailsService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String jwtToken = null;
        String username = null;
        try {
            jwtToken = jwtTokenUtil.getToken(request);
            username = jwtTokenUtil.getUsernameFromToken(jwtToken);
            if (jwtTokenUtil.validateToken(jwtToken,userDetailsService)) {
                AppUserDetails userDetails = (AppUserDetails) userDetailsService.loadUserByUsername(username);
                UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
                        userDetails, null, userDetails.getAuthorities());
                SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
            }
        } catch (ExpiredJwtException ex) {
            ex.printStackTrace();
            request.setAttribute("exception", ex);
        } catch (BadCredentialsException ex) {
            request.setAttribute("exception", ex);
            ex.printStackTrace();
        } catch (IllegalArgumentException ex) {
            request.setAttribute("exception", ex);
            ex.printStackTrace();
        } catch (Exception ex) {
            request.setAttribute("exception", ex);
            ex.printStackTrace();
        }
        chain.doFilter(request, response);
    }
}
