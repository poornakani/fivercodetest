package com.multipixeltec.dcservice.repository;

import com.multipixeltec.dcservice.model.BillPayment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BillPaymentRepository extends JpaRepository<BillPayment, Long> {
}