package com.multipixeltec.dcservice.controller;

import com.multipixeltec.dcservice.enums.*;
import com.multipixeltec.dcservice.exceptions.NotFoundException;
import com.multipixeltec.dcservice.service.*;
import com.multipixeltec.dcservice.dto.ImageDto;
import com.multipixeltec.dcservice.dto.PageDetails;
import com.multipixeltec.dcservice.model.*;
import com.multipixeltec.dcservice.util.FileService;
import com.multipixeltec.dcservice.util.SortColumn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/v1")
public class PatientController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private final PatientService patientService;
    private final TestOrPackageService testOrPackageService;
    private final AgentOrAgencyService agentOrAgencyServicentService;
    private final PatientReportService patientReportService;
    private final BillService billService;
    private final FileService fileService;
    private final CommissionService commissionService;
    private final DiagnosticReportService diagnosticReportService;

    @Value("${application.protocol}")
    private String protocol;

    public PatientController(PatientService patientService, TestOrPackageService testOrPackageService, AgentOrAgencyService agentOrAgencyServicentService, PatientReportService patientReportService, BillService billService, FileService fileService, CommissionService commissionService, DiagnosticReportService diagnosticReportService) {
        this.patientService = patientService;
        this.testOrPackageService = testOrPackageService;
        this.agentOrAgencyServicentService = agentOrAgencyServicentService;
        this.patientReportService = patientReportService;
        this.billService = billService;
        this.fileService = fileService;
        this.commissionService = commissionService;
        this.diagnosticReportService = diagnosticReportService;
    }


    @Transactional(Transactional.TxType.REQUIRES_NEW)
    @PostMapping("/patient")
    public Patient save(@RequestBody Patient patient){
        patient.setStatus(ActiveStatus.ACTIVE);
        boolean isNewRecord = false;
        if (patient.getId() == null){
            isNewRecord = true;
        } else {
            Optional<Patient> optionalPatient = patientService.find(patient.getId());
            optionalPatient.ifPresent(patient1 -> patient.setReport(patient1.getReport()));
        }
        if (patient.getTestOrPackageId()!=null){
            Optional<TestOrPackage> optionalPackage = testOrPackageService.find(patient.getTestOrPackageId());
            optionalPackage.ifPresent(aPackage -> patient.setTestOrPackage(aPackage));
        }
        if (patient.getAgentOrAgencyId()!=null){
            Optional<AgentOrAgency> agent = agentOrAgencyServicentService.find(patient.getAgentOrAgencyId());
            agent.ifPresent(agent1 -> patient.setAgentOrAgency(agent1));
        }
        Patient savedRecord = patientService.save(patient);
        if (isNewRecord) {
            PatientReport report = new PatientReport();
            report.setDefault();
            report.setPatient(savedRecord);
            patientReportService.save(report);

            AgentOrAgency agentOrAgency = patient.getAgentOrAgency();
            double billAmount = savedRecord.getTestOrPackage().getPrice();
            double commissionAmount = 0.0;
            if (agentOrAgency!=null){
                if (agentOrAgency.getCommissionRate()!= null && agentOrAgency.getCommissionRate() > 0){
                    commissionAmount = billAmount*agentOrAgency.getCommissionRate()/100;
                }else{
                    commissionAmount = billAmount - agentOrAgency.getCommissionAmount();
                }
            }

            Bill bill = new Bill();
            bill.setPatient(savedRecord);
            bill.setTest(savedRecord.getTestOrPackage());
            bill.setAgent(savedRecord.getAgentOrAgency());
            bill.setAmount(savedRecord.getTestOrPackage().getPrice());
            bill.setPaid(0.0);
            bill.setStatus(BillStatus.GENERATED);
            bill.setCommission(commissionAmount);
            Bill savedBill = billService.save(bill);
            if (commissionAmount > 0){
                Commission commission = new Commission();
                commission.setBill(savedBill);
                commission.setAmount(commissionAmount);
                commission.setPaid(0.0);
                commission.setDue(commissionAmount);
                commission.setStatus(CommissionStatus.PAYMENT_DUE);
                commission.setAgentOrAgency(agentOrAgency);
                commissionService.save(commission);
            }

            if (patient.getTestOrPackage().getType() == TestPackage.PACKAGE) {
                List<DiagnosticReport> reports =  new ArrayList<>();
                for (PackageItem packageItem : patient.getTestOrPackage().getPackageItems()) {
                    DiagnosticReport diagnosticReport = new DiagnosticReport();
                    diagnosticReport.setPatient(patient);
                    diagnosticReport.setTest(packageItem.getTest());
                    diagnosticReport.setStatus(ReportStatus.PENDING);
                    reports.add(diagnosticReport);
                }
                diagnosticReportService.saveAll(reports);
            }else {
                DiagnosticReport diagnosticReport = new DiagnosticReport();
                diagnosticReport.setPatient(patient);
                diagnosticReport.setTest(patient.getTestOrPackage());
                diagnosticReport.setStatus(ReportStatus.PENDING);
                diagnosticReportService.save(diagnosticReport);
            }
        }
        return savedRecord;
    }

    @GetMapping("/patient/{id}")
    public Optional<Patient> getById(@PathVariable(value = "id") Long id){
        return patientService.find(id);
    }

    @GetMapping("/patient/search")
    public List<Patient> search(@RequestParam(value = "text") String text){
        Pageable pageable = PageRequest.of(0, 6, Sort.by("ID").descending());
        return patientService.searchByText(text,pageable);
    }

    @GetMapping("/patient")
    public List<Patient> getAll(){
        return patientService.findAll();
    }

    @DeleteMapping("/patient/{id}")
    public void deleteById(@PathVariable(value = "id") Long id){
        patientService.delete(id);
    }

    @DeleteMapping("/patient")
    public void deleteAll(){
        patientService.deleteAll();
    }

    @GetMapping("/patient/count")
    public long count(){
        return patientService.count();
    }

    @PostMapping("/patient/advanced")
    public PageDetails getAll(@RequestBody PageDetails page) {
        Sort sort = SortColumn.patient(page.getColumn(),page.getSort());
        Pageable pageable = PageRequest.of(page.getPageNumber(), page.getPageSize(), sort);
        Page<Patient> patientPage;
        if (page.getText()==null || page.getText().isEmpty()){
            patientPage = patientService.findAllByDate(page,pageable);
        }else{
            patientPage = patientService.findAllByDateAndText(page, pageable);
        }
        page.setData(patientPage.getContent());
        page.setTotal(patientPage.getTotalElements());
        return page;
    }


    @PostMapping(path = "/patient/profile")
    public String uploadProfile(@RequestBody ImageDto imageDto,@RequestHeader(HttpHeaders.HOST) String host) {
        String file = protocol+host.concat("/resource/")+fileService.saveFile("patient", imageDto.getFileContentBase64());
        logger.info(file);
        return file;
    }

    @PostMapping(path = "/patient/finger")
    public String uploadFinger(@RequestBody ImageDto imageDto,@RequestHeader(HttpHeaders.HOST) String host) {
        String file = protocol+host.concat("/resource/")+fileService.saveFile("finger", imageDto.getFileContentBase64());
        logger.info(file);
        return file;
    }

    @PostMapping(path = "/patient/{id}/profile")
    public String uploadPatientProfile(@PathVariable("id") Long id, @RequestBody ImageDto imageDto,@RequestHeader(HttpHeaders.HOST) String host) {
        Optional<Patient> optional = patientService.find(id);
        String file="";
        if (optional.isPresent()){
            file = protocol+host.concat("/resource/")+fileService.saveFile("patient", imageDto.getFileContentBase64());
            Patient patient = optional.get();
            patient.setPhoto(file);
            patientService.save(patient);
        }
        return file;
    }

    @PostMapping(path = "/patient/{id}/finger")
    public String uploadPatientFinger(@PathVariable("id") Long id,@RequestBody ImageDto imageDto,@RequestHeader(HttpHeaders.HOST) String host) {
        Optional<Patient> optional = patientService.find(id);
        String file="";
        if (optional.isPresent()){
            file = protocol+host.concat("/resource/")+fileService.saveFile("finger", imageDto.getFileContentBase64());
            Patient patient = optional.get();
            patient.setFingerPrint(file);
            patientService.save(patient);
        }
        return file;
    }
    @PostMapping(path = "/patient/{id}/xray")
    public String uploadPatientXray(@PathVariable("id") Long id,@RequestBody ImageDto imageDto,@RequestHeader(HttpHeaders.HOST) String host) {
        Optional<Patient> optional = patientService.find(id);
        String file="";
        if (optional.isPresent()){
            file = protocol+host.concat("/resource/")+fileService.saveFile("xray", imageDto.getFileContentBase64());
            PatientReport report = optional.get().getReport();
            report.setXRayImage(file);
            patientReportService.save(report);
        }
        return file;
    }
    @GetMapping("/patient/{passportNumber}/passport")
    public Optional<Patient> getById(@PathVariable(value = "passportNumber") String passport){
        List<Patient> patients = patientService.findByPassport(passport);
        if (patients == null || patients.size() == 0) {
            throw new NotFoundException("Patient Report Not Found For Given Passport Number");
        }
        return patients.stream().findFirst();
    }
}
