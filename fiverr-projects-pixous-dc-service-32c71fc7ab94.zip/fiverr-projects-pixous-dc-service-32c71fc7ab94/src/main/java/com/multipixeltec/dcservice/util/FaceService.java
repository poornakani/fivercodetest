package com.multipixeltec.dcservice.util;

import org.opencv.core.*;
import org.opencv.face.EigenFaceRecognizer;
import org.opencv.face.FaceRecognizer;
import org.opencv.face.LBPHFaceRecognizer;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.Arrays;
import java.util.UUID;

/**
 * Copyright (C) 2022 PIXOUS INNOVATIONS - All Rights Reserved
 * You may use, distribute and modify this code under the terms of the XYZ license,
 * which unfortunately won't be written for another century.
 * Project   : dc-service
 * Date      : 2023-01-29
 * Developer : priyamal
 */
@Service
public class FaceService {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Value("${spring.external.path}")
    private String externalPath;

    public boolean detect(String file){
        Mat src = Imgcodecs.imread(file);
        // Instantiating the CascadeClassifier
        CascadeClassifier classifier = new CascadeClassifier(externalPath+"lbpcascade_frontalface.xml");
        // Detecting the face in the snap
        MatOfRect faceDetections = new MatOfRect();
        classifier.detectMultiScale(src, faceDetections);

        // Drawing boxes
        for (Rect rect : faceDetections.toArray()) {
            Imgproc.rectangle(
                    src,// where to draw the box
                    new Point(rect.x, rect.y), // bottom left
                    new Point(rect.x + rect.width, rect.y + rect.height),// top right
                    new Scalar(0, 0, 255),
                    3 // RGB colour
            );
        }

        // Writing the image
        boolean imwrite = Imgcodecs.imwrite(file, src);
        System.out.println("Image Processed");
        return imwrite;
    }

    public String collectFace(String file){
        String facesPath = "";
        // Instantiating the CascadeClassifier
        CascadeClassifier faceCascade = new CascadeClassifier(externalPath+"lbpcascade_frontalface.xml");
        // Load the image
        Mat image = Imgcodecs.imread(file);
        // Convert the image to grayscale
        Mat grayImage = new Mat();
        Imgproc.cvtColor(image, grayImage, Imgproc.COLOR_BGR2GRAY);
        // Detect faces in the grayscale image
        MatOfRect faces = new MatOfRect();
        faceCascade.detectMultiScale(grayImage, faces);
        // Iterate over the faces and crop each one
        int i = 0;
        Rect rect_Crop=null;
        for (Rect rect : faces.toArray()) {
            Imgproc.rectangle(image, new Point(rect.x, rect.y), new Point(rect.x
                    + rect.width, rect.y + rect.height), new Scalar(0, 255, 0));
            rect_Crop = new Rect(rect.x, rect.y, rect.width, rect.height);
            Mat face = new Mat(image, rect_Crop);
            String fileName = UUID.randomUUID().toString();
            facesPath = externalPath+fileName+ ".jpg";
            Imgcodecs.imwrite(facesPath, face);
            i++;
        }
        return facesPath;
    }
    public boolean match(String personA, String personB) {
        logger.info(personA);
        logger.info(personB);
        // Load the cascade classifier for face detection
        CascadeClassifier faceCascade = new CascadeClassifier(externalPath+"lbpcascade_frontalface.xml");

        // Load the first image
        Mat image1 = Imgcodecs.imread(personA);
        // Load the second image
        Mat image2 = Imgcodecs.imread(personB);

        // Convert both images to grayscale
        Mat grayImage1 = new Mat();
        Mat grayImage2 = new Mat();
        Imgproc.cvtColor(image1, grayImage1, Imgproc.COLOR_BGR2GRAY);
        Imgproc.cvtColor(image2, grayImage2, Imgproc.COLOR_BGR2GRAY);

        // Detect faces in both images
        MatOfRect faces1 = new MatOfRect();
        MatOfRect faces2 = new MatOfRect();
        faceCascade.detectMultiScale(grayImage1, faces1);
        faceCascade.detectMultiScale(grayImage2, faces2);
        // If only one face is detected in each image, proceed with recognition
        if (faces1.toArray().length == 1 && faces2.toArray().length == 1) {
            Rect rect1 = faces1.toArray()[0];
            Rect rect2 = faces2.toArray()[0];
            // Crop both faces
            Mat face1 = new Mat(grayImage1, rect1);
            Mat face2 = new Mat(grayImage2, rect2);
            // Resize both faces to a uniform size
            Imgproc.resize(face1, face1, new org.opencv.core.Size(160, 160));
            Imgproc.resize(face2, face2, new org.opencv.core.Size(160, 160));
            // Create the facial recognizer
            FaceRecognizer recognizer = LBPHFaceRecognizer.create();

            // Train the recognizer with the two faces
            recognizer.train(Arrays.asList(face1, face2), new MatOfInt(0, 1));
            // Predict the identity of the second face
            int prediction = recognizer.predict_label(face2);
            logger.info("Face Prediction Result : "+prediction);
        }
        return true;
    }
}
