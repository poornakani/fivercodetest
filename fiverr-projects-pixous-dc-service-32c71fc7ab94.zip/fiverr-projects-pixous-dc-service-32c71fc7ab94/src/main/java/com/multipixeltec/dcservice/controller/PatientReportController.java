package com.multipixeltec.dcservice.controller;

import com.multipixeltec.dcservice.model.Patient;
import com.multipixeltec.dcservice.model.PatientReport;
import com.multipixeltec.dcservice.service.PatientReportService;
import com.multipixeltec.dcservice.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/v1")
public class PatientReportController {

    @Autowired
    private PatientReportService patientreportService;

    @Autowired
    private PatientService patientService;

    @PostMapping("/patient/report")
    public PatientReport save(@RequestBody PatientReport patientreport){
        Optional<Patient> patient = patientService.find(patientreport.getPatientId());
        patient.ifPresent(patient1 -> patientreport.setPatient(patient1));
        return patientreportService.save(patientreport);
    }

    @GetMapping("/patient/report/{id}")
    public Optional<PatientReport> getById(@PathVariable(value = "id") Long id){
        return patientreportService.find(id);
    }

    @GetMapping("/patient/report")
    public List<PatientReport> getAll(){
        return patientreportService.findAll();
    }

    @DeleteMapping("/patient/report/{id}")
    public void deleteById(@PathVariable(value = "id") Long id){
        patientreportService.delete(id);
    }

    @DeleteMapping("/patient/report")
    public void deleteAll(){
        patientreportService.deleteAll();
    }

    @GetMapping("/patient/report/count")
    public long count(){
        return patientreportService.count();
    }
}
