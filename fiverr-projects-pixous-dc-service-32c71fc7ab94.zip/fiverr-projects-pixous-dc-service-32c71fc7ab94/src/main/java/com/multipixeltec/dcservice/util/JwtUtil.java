package com.multipixeltec.dcservice.util;

import com.multipixeltec.dcservice.model.Role;
import io.jsonwebtoken.*;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Copyright (C) 2022 PIXOUS INNOVATIONS - All Rights Reserved
 * You may use, distribute and modify this code under the terms of the XYZ license,
 * which unfortunately won't be written for another century.
 * Project   : dc-service
 * Date      : 2023-01-05
 * Developer : priyamal
 */
@Service
@Setter
public class JwtUtil {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    @Value("${jwt.secret}")
    private String SECRET_KEY;
    @Value("${jwt.expirationDateInMs}")
    private long JWT_EXPIRATIONIN;
    @Value("${jwt.refreshExpirationDateInMs}")
    private long REFRESH_EXPIRATIONDATEIN;

    private SignatureAlgorithm SIGNATURE_ALGORITHM = SignatureAlgorithm.HS256;

    public String generateToken(AppUserDetails userDetails) {
        Date date = new Date(System.currentTimeMillis() + (JWT_EXPIRATIONIN * 1000));
        return Jwts.builder().setClaims(getClaims(userDetails.getUser().getRoles())).setSubject(userDetails.getUsername()).setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(date)
                .signWith(SIGNATURE_ALGORITHM, SECRET_KEY).compact();

    }

    public String generateRefreshToken(AppUserDetails userDetails) {
        Date date = new Date(System.currentTimeMillis() + (REFRESH_EXPIRATIONDATEIN * 1000));
        return Jwts.builder().setClaims(getClaims(userDetails.getUser().getRoles())).setSubject(userDetails.getUsername()).setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(date)
                .signWith(SIGNATURE_ALGORITHM, SECRET_KEY).compact();

    }
     private Map<String, Object> getClaims(Set<Role> rolesList){
        return rolesList.stream().collect(Collectors.toMap(Role::getName, Role::getName));
     }

    public boolean validateToken(String token, UserDetailsService userDetailsService) {
        try {
            final String username = getUsernameFromToken(token);
            UserDetails userDetails = userDetailsService.loadUserByUsername(username);
            return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
        } catch (SignatureException | MalformedJwtException | UnsupportedJwtException | IllegalArgumentException ex) {
            throw new BadCredentialsException("INVALID_CREDENTIALS", ex);
        } catch (ExpiredJwtException ex) {
            throw ex;
        }
    }

    private Boolean isTokenExpired(String token) {
        final Date expiration = getExpirationDateFromToken(token);
        return expiration.before(new Date());
    }

    public Date getExpirationDateFromToken(String token) {
        return getClaimFromToken(token, Claims::getExpiration);
    }

    public String getUsernameFromToken(String token) {
        Claims claims = Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
        return claims.getSubject();

    }

    public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = getAllClaimsFromToken(token);
        return claimsResolver.apply(claims);
    }

    private Claims getAllClaimsFromToken(String token) {
        return Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
    }

    public String getToken(HttpServletRequest request ) {
        String authHeader = request.getHeader("Authorization");
        if ( authHeader != null && authHeader.startsWith("Bearer ")) {
            return authHeader.substring(7);
        }
        return null;
    }
}
