package com.multipixeltec.dcservice.repository;

import com.multipixeltec.dcservice.model.Configuration;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConfigurationRepository extends JpaRepository<Configuration, Long> {
}