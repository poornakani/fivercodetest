package com.multipixeltec.dcservice.repository;

import com.multipixeltec.dcservice.model.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SupplierRepository extends JpaRepository<Supplier, Long> {
}