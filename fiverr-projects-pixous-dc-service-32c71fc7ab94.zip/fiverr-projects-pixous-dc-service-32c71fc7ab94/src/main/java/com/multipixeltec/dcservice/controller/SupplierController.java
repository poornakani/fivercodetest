package com.multipixeltec.dcservice.controller;

import com.multipixeltec.dcservice.model.Supplier;
import com.multipixeltec.dcservice.service.SupplierService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/v1")
public class SupplierController {

    @Autowired
    private SupplierService supplierService;

    @PostMapping("/supplier")
    public Supplier save(@RequestBody Supplier supplier){
        return supplierService.save(supplier);
    }

    @GetMapping("/supplier/{id}")
    public Optional<Supplier> getById(@PathVariable(value = "id") Long id){
        return supplierService.find(id);
    }

    @GetMapping("/supplier")
    public List<Supplier> getAll(){
        return supplierService.findAll();
    }

    @DeleteMapping("/supplier/{id}")
    public void deleteById(@PathVariable(value = "id") Long id){
        supplierService.delete(id);
    }

    @DeleteMapping("/supplier")
    public void deleteAll(){
        supplierService.deleteAll();
    }

    @GetMapping("/supplier/count")
    public long count(){
        return supplierService.count();
    }
}