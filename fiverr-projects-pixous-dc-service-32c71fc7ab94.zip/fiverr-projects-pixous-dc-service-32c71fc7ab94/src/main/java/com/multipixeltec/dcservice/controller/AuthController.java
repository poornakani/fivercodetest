package com.multipixeltec.dcservice.controller;

import com.multipixeltec.dcservice.dto.FaceAuthDto;
import com.multipixeltec.dcservice.dto.JWTRequest;
import com.multipixeltec.dcservice.dto.JWTResponse;
import com.multipixeltec.dcservice.model.Patient;
import com.multipixeltec.dcservice.service.PatientService;
import com.multipixeltec.dcservice.util.*;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Copyright (C) 2022 PIXOUS INNOVATIONS - All Rights Reserved
 * You may use, distribute and modify this code under the terms of the XYZ license,
 * which unfortunately won't be written for another century.
 * Project   : dc-service
 * Date      : 2023-01-04
 * Developer : priyamal
 */
@RestController
@RequestMapping("api/v1")
@CrossOrigin
public class AuthController {
    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;
    private final JwtUserDetailsService userDetailsService;
    private final PatientService patientService;
    private final FileService fileService;
    private final FaceService faceService;
    @Value("${application.protocol}")
    private String protocol;

    public AuthController(AuthenticationManager authenticationManager, JwtUtil jwtUtil, JwtUserDetailsService userDetailsService, PatientService patientService, FileService fileService, FaceService faceService) {
        this.authenticationManager = authenticationManager;
        this.jwtUtil = jwtUtil;
        this.userDetailsService = userDetailsService;
        this.patientService = patientService;
        this.fileService = fileService;
        this.faceService = faceService;
    }

    @PostMapping("/auth/signin")
    public ResponseEntity<?> login(@RequestBody JWTRequest jwtRequest) throws Exception {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(jwtRequest.getEmail(), jwtRequest.getPassword()));
        } catch (DisabledException e) {
            throw new Exception("USER_DISABLED", e);
        } catch (BadCredentialsException e) {
            throw new Exception("INVALID_CREDENTIALS", e);
        }
        AppUserDetails userDetails = (AppUserDetails) userDetailsService.loadUserByUsername(jwtRequest.getEmail());
        String accessToken = jwtUtil.generateToken(userDetails);
        String refreshToken = jwtUtil.generateRefreshToken(userDetails);
        JWTResponse response = new JWTResponse();
        response.setAccessToken(accessToken);
        response.setRefreshToken(refreshToken);
        response.setUser(userDetails.getUser());
        return ResponseEntity.ok(response);
    }

    @RequestMapping(value = "/auth/refresh", method = RequestMethod.GET)
    public ResponseEntity<?> refreshtoken(HttpServletRequest request) throws Exception {
        JWTResponse response = new JWTResponse();
        try {
            String token = jwtUtil.getToken(request);
            String username = jwtUtil.getUsernameFromToken(token);
            AppUserDetails userDetails = (AppUserDetails) userDetailsService.loadUserByUsername(username);
            String accessToken = jwtUtil.generateToken(userDetails);
            response.setAccessToken(accessToken);
            response.setRefreshToken(token);
            response.setUser(userDetails.getUser());
            return ResponseEntity.ok(response);
        } catch (ExpiredJwtException e) {
            response.setError("EXPIRED_REFRESH_TOKEN");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
        } catch (DisabledException e) {
            response.setError("USER_DISABLED");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
        } catch (BadCredentialsException e) {
            response.setError("INVALID_CREDENTIALS");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
        } catch (MalformedJwtException e) {
            response.setError("INVALID_REFRESH_TOKEN");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
        } catch (IllegalArgumentException e) {
            response.setError("NO_AUTH_TOKEN");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
        }
    }


    @GetMapping("/auth/userinfo")
    public ResponseEntity<?> getUserInfo(HttpServletRequest request) {
        String token = jwtUtil.getToken(request);
        String username = jwtUtil.getUsernameFromToken(token);
        AppUserDetails userDetails = (AppUserDetails) userDetailsService.loadUserByUsername(username);
        return ResponseEntity.ok(userDetails.getUser());
    }

    @PostMapping(value = "/auth/face")
    public Object faceAuth(@RequestBody FaceAuthDto dto, @RequestHeader(HttpHeaders.HOST) String host){
        List<Patient> patients = patientService.findAll();
        if (dto.getFace()!=null){
            String path = fileService.saveFace("auth",dto.getFace());
            dto.setFace(path);
            for (Patient patient : patients) {
                if (patient.getPhoto()!=null && !patient.getPhoto().isEmpty()) {
                    logger.info(patient.getPhoto());
                    faceService.match(path, "/home/centos/face_0.jpg");
                }
            }
            return path;
        }
        return dto;
    }

}
